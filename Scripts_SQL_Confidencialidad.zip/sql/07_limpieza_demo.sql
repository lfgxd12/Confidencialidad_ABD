NOAUDIT POLICY pol_conf_clientes;
DROP AUDIT POLICY pol_conf_clientes;
NOAUDIT POLICY pol_conf_privilegiados;
DROP AUDIT POLICY pol_conf_privilegiados;
DROP USER conf_analista;
DROP ROLE rol_consulta_mask;
DROP USER conf_demo CASCADE;
