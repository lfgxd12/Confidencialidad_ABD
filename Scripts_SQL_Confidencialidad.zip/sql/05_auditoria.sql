SET LINESIZE 220 PAGESIZE 100 FEEDBACK ON
COLUMN dbusername FORMAT A15
COLUMN action_name FORMAT A18
COLUMN object_name FORMAT A22
COLUMN unified_audit_policies FORMAT A35
COLUMN policy_name FORMAT A30
PROMPT === OBS-14 Auditoria unificada habilitada
SELECT parameter, value FROM v$option WHERE parameter = 'Unified Auditing';
SELECT policy_name, enabled_option, entity_name, success, failure FROM audit_unified_enabled_policies;

CREATE AUDIT POLICY pol_conf_clientes
  ACTIONS SELECT ON conf_demo.clientes, UPDATE ON conf_demo.clientes,
          SELECT ON conf_demo.v_clientes_mask;
AUDIT POLICY pol_conf_clientes;
CREATE AUDIT POLICY pol_conf_privilegiados
  ACTIONS CREATE USER, ALTER USER, DROP USER, GRANT, REVOKE, CREATE ROLE;
AUDIT POLICY pol_conf_privilegiados;

PROMPT Ahora, desde otra hoja conectada como CONF_ANALISTA, ejecute:
PROMPT SELECT * FROM conf_demo.v_clientes_mask;
PROMPT SELECT * FROM conf_demo.clientes;
PROMPT Regrese a esta hoja y continue.
PAUSE Presione ENTER para consultar la pista de auditoria
EXEC DBMS_AUDIT_MGMT.FLUSH_UNIFIED_AUDIT_TRAIL;

PROMPT === OBS-15 Registros de la pista de auditoria sobre objetos confidenciales
SELECT event_timestamp, dbusername, action_name, object_name, return_code, unified_audit_policies
  FROM unified_audit_trail
 WHERE object_schema = 'CONF_DEMO' OR unified_audit_policies LIKE '%POL_CONF%'
 ORDER BY event_timestamp DESC FETCH FIRST 30 ROWS ONLY;
PROMPT === Retencion y parametros de gestion de la pista
SELECT audit_trail, parameter_name, parameter_value FROM dba_audit_mgmt_config_params;
